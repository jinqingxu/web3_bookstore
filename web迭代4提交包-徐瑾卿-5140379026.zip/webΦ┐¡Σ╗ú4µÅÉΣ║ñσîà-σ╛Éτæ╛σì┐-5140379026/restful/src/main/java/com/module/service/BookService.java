package com.module.service;

import com.module.bean.Book;

/**
 * Created by jinqingxu on 2017/5/19.
 */
public interface BookService {
    public Book querybyname(String bookname);
}
