@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.module.com/")
package com.soap.client;
