package com.module.service;

/**
 * Created by piglet on 2017/4/6.
 */
public interface KeyService {
    public void setPrivateKey(String privateKey);
    public String getPrivateKey();
}
