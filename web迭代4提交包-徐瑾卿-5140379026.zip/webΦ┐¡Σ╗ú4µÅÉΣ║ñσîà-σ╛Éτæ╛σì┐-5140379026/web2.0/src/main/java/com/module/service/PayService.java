package com.module.service;

/**
 * Created by jinqingxu on 2017/5/15.
 */
public interface PayService {
    public String pay(String username,String password)throws Exception;
}
