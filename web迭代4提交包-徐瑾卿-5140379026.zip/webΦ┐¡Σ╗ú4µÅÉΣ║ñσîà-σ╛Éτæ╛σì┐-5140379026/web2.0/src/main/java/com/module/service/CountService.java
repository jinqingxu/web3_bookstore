package com.module.service;

/**
 * Created by piglet on 2017/3/16.
 */
public interface CountService {
    public void setCount(int count);
    public int getCount();
}
