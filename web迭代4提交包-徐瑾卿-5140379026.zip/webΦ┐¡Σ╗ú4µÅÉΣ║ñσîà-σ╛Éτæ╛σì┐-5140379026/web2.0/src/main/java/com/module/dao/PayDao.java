package com.module.dao;

/**
 * Created by jinqingxu on 2017/5/15.
 */
public interface PayDao {
    public String checkpay(String username,String password);
}
