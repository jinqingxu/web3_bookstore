package com.module.service;

/**
 * Created by piglet on 2016/6/12.
 */
public interface OrderitemService {
    public void insert(String orderid,int tmpid,int cartnumber);
}
